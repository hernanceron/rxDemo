package com.lmonkiewicz.example.rxjavaHttp.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RxConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RxConsumerApplication.class, args);
	}
}
